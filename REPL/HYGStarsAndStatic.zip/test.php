<?php phpinfo(); ?>
testing 1 2 3
